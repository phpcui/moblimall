<?php

define('APP_DEBUG' , true);
define('APP_PATH' , __DIR__.'/');  //E:\www\tpshop/
require('./ThinkPHP/ThinkPHP.php');