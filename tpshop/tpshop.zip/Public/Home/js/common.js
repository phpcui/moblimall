function $(element) {
  return document.getElementById(element);
}