<?php
return array(
	//'配置项'=>'配置值'
    'DB_TYPE' => 'mysql' , // 数据库类型
    'DB_HOST' => 'localhost' , // 服务器地址
    'DB_NAME' => 'tpshop1' , // 数据库名
    'DB_USER' => 'root' , // 用户名
    'DB_PWD' => 'cuiwei' , // 密码
    'DB_PREFIX' => '' , // 数据库表前缀
    'LOG_RECORD' => true, // 默认不记录日 志
    'DB_SQL_LOG' => true, //
    'COO_KEY'   =>'dksfaljasjl^&*#%', // cookie密钥
    'V_MID'    =>'20272562', // 管理员可替换为自己的商户号
    'PAYKEY'    => 'KFJ%&*$%#_)O"D<F"S',
    'V_URL'     =>'http://xxx.com/xx.php',
);