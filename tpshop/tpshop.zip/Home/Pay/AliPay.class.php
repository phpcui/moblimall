<?php
namespace Home\Pay;
class AliPay {
}